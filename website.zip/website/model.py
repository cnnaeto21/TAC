from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from passlib.hash import sha256_crypt

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:////tmp/test.db'
db = SQLAlchemy(app)
db.create_all()

#From gcloud python bookshelf tutorial
def from_sql(row):
    """Translates a SQLAlchemy model instance into a dictionary"""
    data = row.__dict__.copy()
    data['id'] = row.id
    data.pop('_sa_instance_state')
    return data

class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), unique = True, nullable = False)
    username = db.Column(db.String(80), unique = True, nullable = False)
    email = db.Column(db.String(250), unique = True, nullable = False)
    password = db.Column(db.String(250), unique = True, nullable = False)
    confirm = db.Column(db.String(250), unique = True, nullable = False)

    def __repr__(self):
        return '<User %r>' % (self.username)

def read_user(id):
    result = User.query.get(id)
    if not result:
        return None
    return from_sql(result)
def create_user(data):
    user = User(**data)
    #user.password = sha256_crypt.encrypt(str())
    db.session.add(user)
    db.session.commit()
    return from_sql(user)

def edit_user(data, id):
    user = User.query.get(id)
    for k, v in data.items():
        setattr(user, k, v)
    db.session.commit()
    return from_sql(user)

def _create_database():
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:////tmp/test.db'
    db = SQLAlchemy(app)
    db.create_all()
    print("All tabs created")
if __name__ == "__main__":
    _create_database()
