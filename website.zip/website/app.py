from flask import Flask, Blueprint, render_template, request, url_for, redirect, logging
from flask_cors import CORS
from passlib.hash import sha256_crypt
from flask_cors import CORS
from passlib.hash import sha256_crypt
from model import create_user, edit_user, _create_database
app = Flask(__name__)

CORS(app)


@app.route('/home')
def home():
    return render_template('home.html')
