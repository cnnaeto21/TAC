from flask import Flask, Blueprint, render_template, request, url_for, redirect, logging
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from passlib.hash import sha256_crypt
from wtforms import Form, StringField, TextAreaField, PasswordField, validators
from model import db, create_user, edit_user, _create_database, User
db.create_all()
app = Flask(__name__)

CORS(app)


@app.route('/home')
def home():
    return render_template('home.html')

class RegisterForm(Form):
    name = StringField('Name', [validators.Length(min=1, max=50)])
    username = StringField('Username', [validators.Length(min=4, max=25)])
    email = StringField('Email', [validators.Length(min=6, max=50)])
    password = PasswordField('Password', [
        validators.DataRequired(),
        validators.EqualTo('confirm', message='Passwords do not match')
    ])
    confirm = PasswordField('Confirm Password')

@app.route('/', methods = ['GET', 'POST'])
#[Adds user to database hopefully]
def register():
    form = RegisterForm(request.form)
    if request.method == 'POST' and form.validate():
        data = request.form.to_dict(flat=True)
        name = form.name.data
        email = form.email.data
        username = form.username.data
        password = sha256_crypt.encrypt(str(form.password.data))
        user = create_user(data)
        db.session.add(user)
        flash("You are now registered")
        return redirect(url_for('home'))
    return render_template('login.html', form = form)
    """if request.method == 'POST':
        if request.form['username'] != 'admin' or request.form['password'] != 'admin':
            error = 'Invalid Credentials. Please try again.'
        else:
            data = request.form.to_dict(flat=True)
            user = create_user(data)
            return redirect(url_for('home'))
    return render_template('login.html', error = error)"""
#[End add]

@app.route('/login', methods = ['GET', 'POST'])
#[User can edit their information]
def edit(id):
    if request.method == 'POST':
        data = request.form.to_dict(flat=True)
        user = edit_user(data, id)
    return render_template('login.html', action = 'Edit')

if __name__ == "__main__":
    app.secret_key = "secret_key"
    _create_database()
    app.run(debug=True)
